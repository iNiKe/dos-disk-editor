/*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <linux/types.h>
#include "part.h"

#ifndef SIGNATURE
#define SIGNATURE 0xAA55
#endif

__u8 mbr[512];


int check_sign()
{
    __u16 sign = 0;

    memcpy((void *)&sign, (void *)(mbr + 0x1FE), 2);

#ifdef DEBUG
    printf("Signature - 0x%X\n", sign);
#endif

    if(sign != SIGNATURE) return -1;

    return 0;
}


void read_main_ptable(int hard)
{
    if(read(hard, mbr, 512) < 0) {
	perror("read");
	close(hard);
	exit(-1);
    }

    memset((void *)pt_t, 0, (PT_SIZE * 4));
    memcpy((void *)pt_t, mbr + 0x1BE, (PT_SIZE * 4));

    return;
}
    


void read_ext_ptable(int hard, __u64 seek)
{
    int num = 4;
    __u8 smbr[512];

/*
 * ������� ������:
 * seek - �������� � ����������� ������� �� ������ ����� (� ������)
 */

    for(;;num++) {

	memset((void *)smbr, 0, 512);
	pread64(hard, smbr, 512, seek);

	memset((void *)&pt_t[num], 0, PT_SIZE * 2);
	memcpy((void *)&pt_t[num], smbr + 0x1BE, PT_SIZE * 2);

	pt_t[num].sect_before += (seek / 512);

        if(!(pt_t[num + 1].type_part)) break;

/* ��������� �������� � ���������� SMBR */
	seek = ((__u64)(pt_t[num].sect_before + pt_t[num].sect_total)) * 512;

    }

    return;
}



int get_pt_info(int hard)
{
    int i = 0;
    __u64 seek;

    read_main_ptable(hard);

    if(check_sign() < 0) {
	printf("Not valid signature!\n");
	return -1;
    }

    for(; i < 4; i++) {
	if((pt_t[i].type_part == 0xF) || \
	    (pt_t[i].type_part == 0x5) || \
	    (pt_t[i].type_part == 0x0C)) {
		seek = (__u64)pt_t[i].sect_before * 512;
		read_ext_ptable(hard, seek);
		break;
	}
    }

    return 0;
}
