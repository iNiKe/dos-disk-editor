/*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


#include "split.h"

int get_name_len(__u8 *full_name)
{
    int len = 0;
    for(; *full_name++ != '\0'; len++);

    return len;
}


int get_name(__u8 *full_name, __u8 *name, int len)
{
    int i = 0;

    for(; i < len; i++) {
	if(full_name[i] == 0x2E) {
	    if((len - (i + 1)) > 3) return -1;
	    else break;
	}
    }

    if(i > 8) return -1;
    memcpy(name, full_name, i);

    return i;
}


int get_ext(__u8 *full_name, __u8 *ext, int len)
{
    if(*full_name == 0x2E) memcpy(ext, full_name + 1, len);
}


int check_name(__u8 *name, int length)
{
    int i, n = 0;
    __u8 forb_symb[] = { 0x22, 0x2A, 0x2B, 0x2C, \
			0x2E, 0x2F, 0x3A, 0x3B, \
			0x3C, 0x3D, 0x3E, 0x3F, \
			0x5B, 0x5C, 0x5D, 0x7C };

    for(; n < length; n++) {
	if(name[n] < 0x20) return -1;
        for(i = 0; i < 16; i++)	if(name[n] == forb_symb[i]) return -1;
    }

    return 0;
}


void upcase(__u8 *name, int len)
{
    int i = 0;

    for(; i < len; i++)
	if((name[i] >= 0x61) && (name[i] <= 0x7A)) name[i] -= 0x20;

    return;
}


int split_name(__u8 *full_name, struct split_name *sn)
{
    int length = 0;

#ifdef DEBUG
    printf("Full name - %s\n", full_name);
    printf("Checking name .. ");
#endif

    length = get_name_len(full_name);
    if(length > SHORT_NAME) return -1;

    sn->name_len = get_name(full_name, sn->name, length);
    if(sn->name_len < 0) return -1;

#ifdef DEBUG
    printf("\nname - %s\n", sn->name);
    printf("length - %d\n", length);
    printf("name length - %d\n", sn->name_len);
#endif

    if(check_name(sn->name, sn->name_len) < 0) return -1;

    if(length > sn->name_len) {

	sn->ext_len = length - sn->name_len - 1;
	if(!sn->ext_len) return -1;
	if(sn->ext_len) {
	    get_ext((full_name + (sn->name_len)), sn->ext, sn->ext_len);

#ifdef DEBUG
	    printf("file`s ext - %s\n", sn->ext);
	    printf("ext length - %d\n", sn->ext_len);
#endif
	    if(check_name(sn->ext, sn->ext_len) < 0) return -1;
	}
    }

    upcase(sn->name, sn->name_len);
    if(sn->ext_len) upcase(sn->ext, sn->ext_len);

#ifdef DEBUG
    printf("%s\n", sn->name);
    printf("%s\n", sn->ext);
#endif

    return 0;
}

