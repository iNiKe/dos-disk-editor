
                               WINIMAGE 6.10
                      Copyright 1993-2002 Gilles Vollant

For Windows 95/98/Me, Windows NT/2000/XP and Windows 3.1 with Win32s




PURPOSE
~~~~~~~
This Zipfile contains WinImage 6.10, standard and professional
version, and the self extractor.

This is the English version of WinImage 6.10. For other languages,
you need to download the translation Zipfile on the WinImage Internet
Web site http://www.winimage.com/download.htm .


STEP ONE
~~~~~~~~
You need to extract winima61.zip in a new directory (for example,
c:\winimage). You can use WinZip (http://www.winzip.com) for this
task.

You can also start the install file winima61.exe.


STEP TWO
~~~~~~~~
If you are running MSDOS + Windows 3.1x, you need to install Win32s 1.30.
There is a link to download Win32s at http://www.winimage.com/othertl.htm
You can also add FDREAD.EXE to your AUTOEXEC.BAT to read 1.68/DMF floppies.

(Note : FDREAD is only for MSDOS 5.x/6.x, NOT for Windows 9x/Me/NT/2000/XP)


STEP THREE
~~~~~~~~~~
If you want to run WinImage, just run WinImage.exe.

The full documentation is in the WinImaUS.HLP help file. The additional
features of WinImage 6.10 are in the "Evolution of WinImage topic".

Don't hesitate check the web site for up-to-date info.


Gilles Vollant
mailto:info@winimage.com
http://www.winimage.com
http://www.winimage.com/order.htm (for ordering a license)
